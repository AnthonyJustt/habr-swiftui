//
//  SwiftSoup.h
//  SwiftSoup
//
//  Created by Nabil Chatbi on 09/10/16.
//  Copyright © 2016 Nabil Chatbi.. All rights reserved.
//



