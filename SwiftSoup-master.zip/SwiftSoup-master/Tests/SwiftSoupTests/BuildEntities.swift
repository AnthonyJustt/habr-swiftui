//
//  BuildEntities.swift
//  SwiftSoup
//
//  Created by Nabil Chatbi on 31/10/16.
//  Copyright © 2016 Nabil Chatbi.. All rights reserved.
//

import Foundation
//todo:
