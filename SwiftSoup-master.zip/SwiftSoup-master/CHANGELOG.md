# Change Log

All notable changes to this project will be documented in this file.

## [2.3.2](https://github.com/scinfu/SwiftSoup/tree/2.3.2)
* Renamed Selector Class to CssSelector

## [1.7.4](https://github.com/scinfu/SwiftSoup/tree/1.7.4)
* Removed Some warnings
* Swift 4.2

## [1.7.1](https://github.com/scinfu/SwiftSoup/tree/1.7.1)
* Backward compatibility for Swift < 4.1

## [1.7.0](https://github.com/scinfu/SwiftSoup/tree/1.7.0)
* Removed StringBuilder from Element.cssSelector
* Lint Code
* Swift 4.1

## [1.6.5](https://github.com/scinfu/SwiftSoup/tree/1.6.5)
* Removed StringBuilder from Element.cssSelector
* Lint Code


## [1.6.4](https://github.com/scinfu/SwiftSoup/tree/1.6.4)
* Add newer simulators to targeted devices to build with Carthage [tvOS]

## [1.6.3](https://github.com/scinfu/SwiftSoup/tree/1.6.3)

* Add newer tvOS simulators to targeted devices to build with Carthage.
* Add newer watchOS simulators to targeted devices to build with Carthage.
