---
name: Having a problem
about: Ask for help about a problem
title: 'Issue: Auto-dismiss not working'
labels: good first issue
assignees: ''

---

## Expected Behavior


## Actual Behavior


## Steps to Reproduce the Problem

  1.
  2.
  3.

## Specifications

  - SwiftUI Version:
  - Platform (iOS or macOS):
